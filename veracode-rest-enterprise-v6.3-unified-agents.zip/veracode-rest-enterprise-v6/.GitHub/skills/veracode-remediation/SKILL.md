---
name: veracode-remediation
description: Select a project/module from .GitHub/output, use its latest successful raw results.json, trace and remediate confirmed Veracode findings, validate changes, and generate patch evidence.
---

# Veracode Remediation Skill

## 1. Source of truth

The sole authoritative vulnerability input is a raw Pipeline Scan file named
`results.json` under `.GitHub/output`.

Do not substitute CSV files, `veracode-findings.json`, manually typed summaries,
or findings from another scan when `results.json` exists.

## 2. Discover valid projects/modules

Inspect immediate child directories of:

`.GitHub/output/`

A valid project/module contains at least one `results.json` in either layout:

```text
.GitHub/output/<project>/<YYYY-MM-DD>/results.json
.GitHub/output/<project>/<YYYY-MM-DD>/<HHMMSS>/results.json
.GitHub/output/<project>/src/<YYYY-MM-DD>/results.json
.GitHub/output/<project>/src/<YYYY-MM-DD>/<HHMMSS>/results.json
```

Rules:

- `<project>` is always the directory immediately below `.GitHub/output`.
- `src` is only the mainframe layout marker. Never display or use `src` as the
  project/module name.
- Ignore folders that contain no supported `results.json`.

## 3. Select the project/module

- Use a valid project/module explicitly named by the user.
- If exactly one valid project/module exists, select it automatically and state it.
- If two or more valid projects/modules exist, show a numbered list and ask exactly:

  `Select the project/module to remediate by number or name:`

Wait for the selection before changing source files.

Do not ask the user to select a scan date.

## 4. Select the latest scan automatically

For the selected project, inspect standard and mainframe layouts and choose the
newest scan by:

1. newest valid `YYYY-MM-DD` date directory;
2. newest timestamp/run subdirectory on that date;
3. newest `results.json` modification time when still tied.

Prefer a sibling `scan-status.json` showing a successful/completed scan. Skip any
scan folder without `results.json`.

State the exact repository-relative selected `results.json` path before editing.
Do not combine findings from different scans.

## 5. Parse findings defensively

For each finding, capture every available field, including:

- finding/flaw/issue ID;
- CWE;
- severity;
- title/category;
- module;
- source file and line;
- method/function/procedure;
- untrusted source;
- risky sink;
- description and remediation guidance;
- data path/call stack;
- status.

Never fabricate missing fields. Use `Not present in results.json` where needed.

## 6. Finding-by-finding remediation

For every confirmed finding:

1. Establish identity: ID, CWE, severity, file, line, method, module.
2. Locate the reported security-sensitive sink.
3. Trace only the relevant data flow:
   `untrusted source -> transformations -> validation/encoding -> sink`.
4. Determine the real root cause, not merely the reported line.
5. Apply the smallest technically correct source change.
6. Preserve APIs, business behavior, database semantics, authentication,
   authorization, error behavior, and logging intent.
7. Compile/test the narrowest affected scope when tooling is available.
8. Record validation limitations precisely.

Never scan unrelated source merely to expand context.

## 7. Preferred remediation patterns

- **CWE-79/80 XSS:** framework templating and context-aware output encoding;
  never bypass Angular sanitization.
- **CWE-89 SQL injection:** prepared statements, bind variables, named
  parameters, and explicit allowlists for dynamic identifiers.
- **CWE-113 CRLF/response splitting:** reject CR/LF and use framework-safe header
  APIs or strict allowlists.
- **CWE-117 log forging:** parameterized/structured logging and centralized
  CR/LF/control-character neutralization without removing security logs.
- **CWE-22 path traversal:** trusted base, resolve, normalize, and verify the
  final path remains inside the base.
- **CWE-78 command injection:** avoid shells; fixed executable plus separated,
  allowlisted arguments.
- **CWE-601 open redirect:** relative destinations or explicit allowlists.

Avoid blanket stripping, generic regex sanitizers, catch-and-ignore, hard-coded
safe values, security-control removal, or broad unrelated refactoring.

## 8. Generate remediation output

Derive `<scan-date>` from the selected scan's date directory, not from today's
clock date.

Create:

```text
.GitHub/remediation/<project-or-module>/<scan-date>/
```

For each remediated finding write a standard unified-diff patch:

```text
finding-<finding-id>-cwe-<cwe>.patch
```

Use `unknown` only when the corresponding value is absent. Add `-2`, `-3`, and so
on only to avoid a filename collision.

Patch rules:

- repository-relative source paths;
- only files changed for that finding;
- no credentials, tokens, binaries, generated build output, or scan-result files;
- deterministic filenames.

Also write:

```text
remediation-report.md
selected-scan.json
```

`selected-scan.json` must record:

- selected project/module;
- layout: `mainframe` or `standard`;
- selected repository-relative `results.json` path;
- selected scan date;
- timestamp/run folder when present;
- remediation start time;
- generated patch filenames.

For every report entry include finding evidence, root cause, remediation decision,
changed files, validation, result, and status:

`REMEDIATED_PENDING_VERACODE_RESCAN`

Only a new Veracode scan can establish `VERIFIED`.
