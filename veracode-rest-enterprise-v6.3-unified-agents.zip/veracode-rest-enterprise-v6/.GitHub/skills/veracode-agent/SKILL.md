---
name: veracode-agent
description: Launch the repository's interactive Veracode Windows batch workflow in the IntelliJ integrated terminal, restarting the workflow from step one every time.
---

# Veracode Scan Launcher Skill

## Purpose

Use this skill only to start the packaged Veracode scan workflow. The batch
launcher owns runtime setup, credential collection, application selection,
packaging, API calls, and result generation.

## Repository requirements

Expected paths from the repository root:

```text
veracode-enterprise/runtime-veracode.bat
veracode-enterprise/run-Veracode.bat
veracode-enterprise/setup-runtime.bat
veracode-enterprise/app/
veracode-enterprise/config/
```

## Execution rule

Every time the user starts the agent, execute a new command in the IntelliJ
integrated terminal from the repository root:

```bat
veracode-enterprise\runtime-veracode.bat
```

If the integrated terminal shell is PowerShell, invoke through `cmd.exe` so batch
syntax is interpreted correctly:

```powershell
cmd.exe /d /c "veracode-enterprise\runtime-veracode.bat"
```

If the integrated terminal shell is Command Prompt, run the batch path directly.

Do not run `call` as a PowerShell command. Do not run individual Python scripts
from Copilot. Do not reuse or continue a previous batch-process state.

## Interaction and security

- Leave the command interactive.
- Terminal prompts collect HMAC API ID and hidden API key when required.
- Never copy credentials into Copilot chat, output files, logs, or agent reports.
- The default API host remains `api.veracode.com`.
- If the batch exits with an error, report the visible terminal error and allow
  the next `Start Veracode API scan` request to start again from step one.

## Successful completion

The batch workflow generates results under:

```text
.GitHub/output/<project-or-module>/src/<date>/       # mainframe
.GitHub/output/<project-or-module>/<date>/           # other applications
```
