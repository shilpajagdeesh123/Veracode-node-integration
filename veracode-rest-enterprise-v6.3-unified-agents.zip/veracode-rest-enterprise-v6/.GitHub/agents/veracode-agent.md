---
name: veracode-agent
description: Starts the Veracode Enterprise scan workflow from the repository root in the IntelliJ integrated terminal by running veracode-enterprise\runtime-veracode.bat from the beginning on every invocation.
---

# Veracode Enterprise Scan Agent

## Mandatory skill

Read and follow:

`.GitHub/skills/veracode-agent/SKILL.md`

## Start command

When the developer selects this agent and enters:

`Start Veracode API scan`

immediately open/use the IntelliJ integrated terminal at the repository root and
run:

```bat
veracode-enterprise\runtime-veracode.bat
```

## Required behavior on every invocation

- Always launch the batch file again from its first step.
- Never assume a previous terminal run is still active or complete.
- Never skip runtime, credential, project selection, packaging, upload, scan, or
  result-generation steps because of prior conversation/session state.
- Do not implement the scan inside Copilot chat.
- Do not print or request HMAC credentials in chat. Credential prompts must remain
  inside the terminal workflow.
- Keep the terminal interactive so the user can answer project/module and
  credential prompts.
- Do not run PowerShell commands or use `call` as a PowerShell command.
