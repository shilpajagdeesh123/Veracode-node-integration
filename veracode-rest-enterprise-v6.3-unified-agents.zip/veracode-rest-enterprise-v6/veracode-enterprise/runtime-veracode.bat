@echo off
setlocal EnableExtensions DisableDelayedExpansion

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"

rem This wrapper intentionally starts the scan launcher from step one on every run.
rem No previous process/session state is reused.
cd /d "%TOOL_HOME%"

cls
echo ==========================================================
echo  Veracode Enterprise - New Scan Session
echo ==========================================================
echo Starting the complete workflow from Step 1...
echo.

call "%TOOL_HOME%\run-Veracode.bat"
set "EXIT_CODE=%ERRORLEVEL%"

exit /b %EXIT_CODE%
