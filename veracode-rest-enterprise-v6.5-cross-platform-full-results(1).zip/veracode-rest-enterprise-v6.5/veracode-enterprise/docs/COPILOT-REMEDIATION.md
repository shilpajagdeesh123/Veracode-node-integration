# Copilot remediation — V4.5

After a scan, V4.5 installs into the repository:

```text
.GitHub/agents/veracode-remediation-agent.md
.GitHub/skills/veracode-remediation/SKILL.md
```

## Input

The authoritative input is:

```text
.GitHub/output/veracode/<target>/<latest-scan>/results.json
```

## Run

Select:

`veracode-remediation-agent`

Prompt:

```text
Remediate the latest Veracode findings for <target> using results.json.
```

The agent/skill should:

1. locate the newest successful scan;
2. read raw `results.json`;
3. identify each finding;
4. map it to source;
5. inspect the minimum required call/data-flow hierarchy;
6. identify root cause;
7. apply safe CWE-specific remediation;
8. build/test;
9. create `remediation-report.md`;
10. mark fixes `REMEDIATED_PENDING_VERACODE_RESCAN`.

Then run V4.5 again to verify remediation.
