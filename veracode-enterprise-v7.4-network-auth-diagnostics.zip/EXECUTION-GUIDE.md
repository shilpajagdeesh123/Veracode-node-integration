# Veracode Enterprise V7.4 Execution Guide

## Package layout

Extract the ZIP into the repository root. The following entries must be siblings:

```text
.github/
veracode-enterprise/
veracode-enterprise/run-veracode.bat
veracode-enterprise/run-veracode.cmd
veracode-enterprise/run-veracode.sh
```

Node.js 18 or later must already be available. No administrator rights, Python, Java, Go, PowerShell script, native executable, or `npm install` is required.

## Option 1 — GitHub Copilot agent

1. Open the repository root in the Copilot-enabled IDE.
2. Select `veracode-agent` in Agent mode.
3. Enter: `Start Veracode API scan.`
4. Approve `node ./veracode-enterprise/src/index.js --fresh-start`.
5. Every invocation starts a new Node.js process at step 1. It does not reuse a previous project selection or scan session.
6. The application checks `veracode-enterprise/config/veracode-secrets.json`.
7. When the file is absent or incomplete, enter the HMAC API ID and hidden HMAC API key in the Copilot internal terminal.
8. The agent validates network access and HMAC authentication before project selection and packaging.
9. Select a scan mode and project/module or existing package.

A fresh start preserves valid saved credentials and previous `.github/Output` and `.github/remediation` content.

## Option 2 — Windows terminal without Copilot

From the repository root run:

```text
veracode-enterprise\run-veracode.bat
```

You can also double-click `veracode-enterprise\run-veracode.bat`, although running it in an existing Command Prompt or PowerShell window makes errors easier to review.

## Option 3 — macOS or Linux terminal without Copilot

From the repository root run:

```text
./veracode-enterprise/run-veracode.sh
```

If executable permission was removed while transferring the ZIP, run `chmod +x veracode-enterprise/run-veracode.sh` once.

## Direct Node.js command

```text
node ./veracode-enterprise/src/index.js --fresh-start
```

## Credentials

Credentials are stored only in:

```text
veracode-enterprise/config/veracode-secrets.json
```

The default host is `api.veracode.com`. The secret file is excluded from Git. Delete only this file when credentials must be replaced; do not share it.

## Results

Use `results.json` as the authoritative remediation input. `results.csv` is generated only for readability.

## Troubleshooting

- `node is not recognized` or `node: command not found`: make the organization-approved Node.js 18+ runtime available in PATH.
- Credentials prompt appears every run: verify the secrets file exists, contains non-template values, and is readable.
- `fetch failed`: the package now prints the network code, URL, cause, retry attempts, and proxy status. Check DNS, firewall, TLS inspection, and proxy access to `api.veracode.com:443`.
- Authentication error: delete only `veracode-enterprise/config/veracode-secrets.json`, rerun, and carefully enter the credentials in the terminal.
- No project found: confirm the repository contains a supported Maven, Angular, Node.js, or mainframe project.
