@echo off
setlocal EnableExtensions DisableDelayedExpansion
for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
cd /d "%TOOL_HOME%"

rem Fresh execution state on every start. Credentials and historical reports are preserved.
if exist "%TOOL_HOME%\runtime\session" rmdir /s /q "%TOOL_HOME%\runtime\session" >nul 2>&1
mkdir "%TOOL_HOME%\runtime\session" >nul 2>&1
set "VERACODE_SESSION_ID=%RANDOM%%RANDOM%-%DATE:/=-%-%TIME::=-%"

cls
echo ==========================================================
echo  Veracode Enterprise - Fresh Scan Session
echo ==========================================================
echo Starting the workflow from Step 1...
echo.
call "%TOOL_HOME%\run-Veracode.bat"
exit /b %ERRORLEVEL%
