#!/usr/bin/env python3
from __future__ import annotations

import getpass
import json
import re
import sys
from pathlib import Path


def main() -> int:
    if len(sys.argv) != 2:
        print("ERROR: Tool home argument is required.", file=sys.stderr)
        return 2

    tool_home = Path(sys.argv[1]).resolve()
    secret_path = tool_home / "config" / "veracode-secrets.json"

    if secret_path.exists():
        try:
            data = json.loads(secret_path.read_text(encoding="utf-8"))
            api_id = str(data.get("api_id", "")).strip()
            api_key = str(data.get("api_key", "")).strip()
            if api_id and api_key:
                print(f"Veracode credentials already configured: {secret_path}")
                return 0
        except Exception:
            pass

    print()
    print("Veracode HMAC credentials are missing or incomplete.")
    api_id = input("HMAC API ID: ").strip()
    api_key = getpass.getpass("HMAC API key (hidden): ").strip()

    if not api_id:
        print("ERROR: HMAC API ID cannot be empty.", file=sys.stderr)
        return 3
    if not api_key:
        print("ERROR: HMAC API key cannot be empty.", file=sys.stderr)
        return 3
    if len(api_key) % 2 != 0 or not re.fullmatch(r"[0-9A-Fa-f]+", api_key):
        print("ERROR: HMAC API key must be a complete hexadecimal value.", file=sys.stderr)
        return 3

    secret_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = secret_path.with_suffix(".json.tmp")
    temp_path.write_text(json.dumps({
        "api_id": api_id,
        "api_key": api_key,
        "api_host": "api.veracode.com"
    }, indent=2), encoding="utf-8")
    temp_path.replace(secret_path)
    print(f"Credentials saved locally: {secret_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
