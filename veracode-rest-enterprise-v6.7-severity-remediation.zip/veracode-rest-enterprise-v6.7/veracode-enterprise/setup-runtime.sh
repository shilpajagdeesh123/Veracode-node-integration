#!/usr/bin/env bash
set -euo pipefail
TOOL_HOME="$(cd "$(dirname "$0")" && pwd)"
RUNTIME_DIR="$TOOL_HOME/runtime/python"
WRAPPER="$RUNTIME_DIR/python3"

if [[ -x "$WRAPPER" ]]; then
  "$WRAPPER" --version
  exit 0
fi

if ! command -v python3 >/dev/null 2>&1; then
  echo "ERROR: Python 3 is not available on this macOS machine." >&2
  echo "Install an organization-approved Python 3 runtime, then run this script again." >&2
  exit 2
fi

mkdir -p "$RUNTIME_DIR"
cat > "$WRAPPER" <<'EOF'
#!/usr/bin/env bash
exec /usr/bin/env python3 "$@"
EOF
chmod 700 "$WRAPPER"
echo "macOS Python runtime wrapper initialized:"
"$WRAPPER" --version
