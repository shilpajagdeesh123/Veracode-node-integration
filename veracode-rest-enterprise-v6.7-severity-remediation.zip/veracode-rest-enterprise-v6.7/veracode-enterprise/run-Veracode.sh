#!/usr/bin/env bash
set -euo pipefail
TOOL_HOME="$(cd "$(dirname "$0")" && pwd)"
PYTHON_EXE="$TOOL_HOME/runtime/python/python3"

echo "=========================================================="
echo " Veracode Enterprise Scan Launcher - macOS"
echo "=========================================================="
echo

echo "Step 1: Checking Python runtime..."
if [[ ! -x "$PYTHON_EXE" ]]; then
  echo "Local runtime wrapper was not found. Running setup-runtime.sh..."
  "$TOOL_HOME/setup-runtime.sh"
fi
[[ -x "$PYTHON_EXE" ]] || { echo "ERROR: Python runtime is unavailable." >&2; exit 2; }
"$PYTHON_EXE" --version

echo
echo "Step 2: Checking Veracode HMAC credentials..."
"$PYTHON_EXE" "$TOOL_HOME/app/configure_credentials.py" "$TOOL_HOME"

echo
echo "Step 3: Starting Veracode scan workflow..."
"$PYTHON_EXE" "$TOOL_HOME/app/veracode_precommit.py" --tool-home "$TOOL_HOME"
