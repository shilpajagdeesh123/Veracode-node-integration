# Setup and execution

## GitHub Copilot agent

1. Keep `.GitHub` and `veracode-enterprise` at repository root.
2. Select `veracode-agent` in Copilot Agent mode.
3. Enter `Start Veracode API scan`.
4. The agent detects Windows or macOS, submits the platform launcher to a fresh IntelliJ terminal, and stops immediately.
5. Complete credential and project prompts only in the terminal.

## Direct terminal

Windows: `veracode-enterprise\runtime-veracode.bat`

macOS: `bash veracode-enterprise/runtime-veracode.sh`

Every run clears transient runtime session state and starts from Step 1. It does not delete credentials or historical results.

Scan output: `.GitHub/output/veracode/<project-or-module>/<date>/`

Remediation output: `.GitHub/remediation/veracode/<project-or-module>/<scan-date>/`
