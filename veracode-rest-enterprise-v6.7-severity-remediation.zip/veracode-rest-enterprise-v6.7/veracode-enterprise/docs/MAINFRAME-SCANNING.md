# Mainframe scanning

V5 detects and packages mainframe source including:

```text
.cbl .cob .cobol .cpy .copy .pco .jcl .bms .pli .pl1 .asm .s .mac
```

Example:

```text
mainframe-customer\
├── src\
│   ├── CUSTOMER.cbl
│   └── ACCOUNT.cob
├── copybook\
│   ├── CUSTOMER.cpy
│   └── ACCOUNT.cpy
└── jcl\
    └── CUSTOMER.jcl
```

Run:

```bat
run-veracode.bat
```

Choose PROJECT or MODULE, then select the target marked `(mainframe)`.

The package preserves relative paths and creates:

```text
<target>-<scope>-MAINFRAME.zip
```

It then submits that ZIP through the same Veracode Pipeline Scan REST/HMAC workflow.

V5 does not modify source encodings or copybook layouts.

## Mainframe output naming

When the scanner target is a physical `src` directory, the parent directory is
used as the module/project name. For example:

```text
repository/payment-module/src
```

produces:

```text
repository/.GitHub/output/payment-module/src/YYYY-MM-DD
```

It will not create `.GitHub/output/src/src/YYYY-MM-DD`.
