# Windows execution — V4 Python

## Why V4

This version avoids PowerShell completely.

It is suitable for Windows machines where:

`MachinePolicy = AllSigned`

because the scanner runs from `.bat` + a local Python runtime.

## First run

1. Extract V4 beside/inside the repository.
2. Open Command Prompt.
3. Set Veracode HMAC credentials:

```bat
set VERACODE_API_KEY_ID=YOUR_ID
set VERACODE_API_KEY_SECRET=YOUR_SECRET
```

4. Run:

```bat
run-veracode.bat
```

If `runtime\python\python.exe` is not present, `run-veracode.bat`
automatically calls:

```bat
setup-runtime.bat
```

The setup:
- downloads the official Python 3.13.14 Windows embeddable ZIP from python.org;
- verifies the published SHA-256;
- extracts Python under `runtime\python`;
- does not install Python into Windows;
- does not require admin rights;
- does not modify PATH.

After first setup, subsequent runs use the local runtime directly.

## Offline enterprise installation

If internet downloads are blocked, ask desktop engineering to place:

`python-3.13.14-embed-amd64.zip`

under:

`runtime\download\`

Then run:

`setup-runtime.bat`

The same SHA-256 verification is performed before extraction.

## Scan output

```text
<repository>\
└── .github\
    └── Output\
        └── <project-or-module>\
            └── YYYY-MM-DD\
                ├── results.json
                ├── veracode-findings.json
                ├── scan-status.json
                ├── scan-metadata.json
                ├── remediation-report.md
                └── package\
```

Repeated scans on the same date use a timestamp subdirectory.

## Module scan

Choose `MODULE`, then select the desired Maven/Angular/Node target.

For Maven, V4 builds that target and submits the selected JAR/WAR/EAR.

## Project scan

Choose `PROJECT`.

For Maven, V4 builds the selected Maven root and packages discovered JAR/WAR/EAR outputs beneath that root into one scan ZIP.

For Angular/Node, V4 creates a source-oriented ZIP while excluding generated/dependency folders.

## Copilot

V4 copies the remediation agent to:

`.github\agents\veracode-remediation-agent.md`

Select it and use:

`Remediate the latest Veracode findings for <target> under .GitHub/output.`

Then rerun `run-veracode.bat`.
