@echo off
setlocal EnableExtensions

for %%I in ("%~dp0.") do set "TOOL_HOME=%%~fI"
set "PYTHON_EXE=%TOOL_HOME%\runtime\python\python.exe"

echo ==========================================================
echo  Veracode Enterprise Scan Launcher
echo ==========================================================
echo.

echo Step 1: Checking bundled Python runtime...
if not exist "%PYTHON_EXE%" (
    echo Bundled Python runtime was not found.
    echo Running setup-runtime.bat...
    call "%TOOL_HOME%\setup-runtime.bat"
    if errorlevel 1 (
        echo.
        echo ERROR: Python runtime setup failed.
        exit /b 2
    )
)

if not exist "%PYTHON_EXE%" (
    echo ERROR: Python runtime is still unavailable after setup.
    exit /b 2
)

"%PYTHON_EXE%" --version
if errorlevel 1 (
    echo ERROR: Bundled Python runtime could not start.
    exit /b 2
)

echo.
echo Step 2: Checking Veracode HMAC credentials...
"%PYTHON_EXE%" "%TOOL_HOME%\app\configure_credentials.py" "%TOOL_HOME%"
if errorlevel 1 (
    echo.
    echo ERROR: Veracode credential setup failed.
    exit /b 3
)

if not exist "%TOOL_HOME%\config\scanner.json" (
    echo ERROR: scanner.json was not found:
    echo   %TOOL_HOME%\config\scanner.json
    exit /b 4
)

echo.
echo Step 3: Starting Veracode scan workflow...
echo Tool home: %TOOL_HOME%
echo.
"%PYTHON_EXE%" "%TOOL_HOME%\app\veracode_precommit.py" --tool-home "%TOOL_HOME%"
set "EXIT_CODE=%ERRORLEVEL%"

echo.
if "%EXIT_CODE%"=="0" (
    echo Veracode workflow completed successfully.
) else (
    echo Veracode workflow ended with exit code %EXIT_CODE%.
)
exit /b %EXIT_CODE%
