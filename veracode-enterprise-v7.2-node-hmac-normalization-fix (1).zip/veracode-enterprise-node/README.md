# Veracode Enterprise Agent V7.1 — Node.js

Cross-platform GitHub Copilot Veracode Pipeline Scan package for Windows and macOS.

## Requirements

- Node.js 18 or later already available on the developer machine.
- Valid Veracode HMAC API credentials.
- Network access to `api.veracode.com`.
- No administrator rights are required.
- No Python, Java, Go, PowerShell script, native executable, or third-party npm package is used.

## Copilot execution

Select `veracode-agent` in Agent mode and enter:

```text
Start Veracode API scan.
```

Copilot runs:

```text
node ./veracode-enterprise-node/src/index.js
```

## First run

The terminal requests the HMAC API ID and then the HMAC API key using hidden input. Credentials are stored locally in `config/veracode-secrets.json`. Do not commit this file.

## Outputs

For mainframe modules:

```text
.github/Output/<module>/src/<date>/results.json
.github/Output/<module>/src/<date>/results.csv
.github/remediation/<module>/src/<date>/
```

`results.json` is the authoritative remediation input. CSV is provided for readability only.

## Tests

```text
cd veracode-enterprise-node
npm test
```

No `npm install` is required because the project has no external dependencies.
