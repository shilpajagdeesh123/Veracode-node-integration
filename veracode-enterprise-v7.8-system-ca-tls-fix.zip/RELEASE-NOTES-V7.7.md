# Veracode Enterprise V7.7

- Credential bootstrap now uses file-presence semantics.
- If `veracode-enterprise/config/veracode-secrets.json` exists, credential prompting is bypassed.
- If the file does not exist, the launcher asks for the HMAC API ID and hidden HMAC API key, saves the file, and starts the scan workflow.
- The same behavior is used by Windows batch/CMD and macOS/Linux shell launchers.
