import fs from 'node:fs';
import path from 'node:path';
import { ask, readSecret } from './terminal.js';
import { readJson, writeJson } from './utils.js';

function cleanCredential(value) {
  return String(value ?? '')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .trim();
}

export function normalizeSecrets(value) {
  // JSON.parse can legitimately return null, a string, number, or array.
  // Treat every non-object/array value as an empty credential object so a
  // missing, empty, malformed, or "null" file results in a clean prompt.
  const source = value && typeof value === 'object' && !Array.isArray(value)
    ? value
    : {};

  return {
    api_id: cleanCredential(source.api_id),
    api_key: cleanCredential(source.api_key),
    api_host: cleanCredential(source.api_host) || 'api.veracode.com'
  };
}

export function credentialsAreValid(secrets) {
  const normalized = normalizeSecrets(secrets);
  return Boolean(
    normalized.api_id &&
    normalized.api_key &&
    !normalized.api_id.toUpperCase().startsWith('REPLACE_') &&
    !normalized.api_key.toUpperCase().startsWith('REPLACE_')
  );
}

export async function loadOrPromptCredentials(home) {
  const file = path.join(home, 'config', 'veracode-secrets.json');

  // Requested launcher rule: presence of the secrets file is the bypass
  // condition. Do not ask for credentials again when the file already exists.
  // Authentication validation later in the workflow will report bad values.
  if (fs.existsSync(file)) {
    console.log('Existing veracode-secrets.json found. Credential prompt bypassed.');
    return normalizeSecrets(readJson(file, null));
  }

  console.log('Veracode HMAC credentials are missing or incomplete.');
  const api_id = cleanCredential(await ask('HMAC API ID'));
  const api_key = cleanCredential(await readSecret('HMAC API key (hidden)'));
  const secrets = normalizeSecrets({ api_id, api_key, api_host: 'api.veracode.com' });

  if (!secrets.api_id) throw new Error('HMAC API ID is required.');
  if (!secrets.api_key) throw new Error('HMAC API key is required.');

  writeJson(file, secrets, 0o600);
  try { fs.chmodSync(file, 0o600); } catch {}
  console.log('Credentials saved locally...');
  return secrets;
}
