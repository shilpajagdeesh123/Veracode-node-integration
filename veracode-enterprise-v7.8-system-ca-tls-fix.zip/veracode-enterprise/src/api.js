import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { authorizationHeader } from './hmac.js';
import { sleep } from './utils.js';

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);
const RETRYABLE_CODES = new Set(['ECONNRESET', 'ECONNREFUSED', 'EAI_AGAIN', 'ENETUNREACH', 'ETIMEDOUT', 'UND_ERR_CONNECT_TIMEOUT', 'UND_ERR_HEADERS_TIMEOUT', 'UND_ERR_SOCKET']);

export class VeracodeApiError extends Error {
  constructor(message, { status, code, url, cause } = {}) {
    super(message, { cause });
    this.name = 'VeracodeApiError';
    this.status = status;
    this.code = code;
    this.url = url;
  }
}

function causeCode(error) {
  return error?.cause?.code || error?.code || '';
}

function networkMessage(error, url) {
  const code = causeCode(error);
  const detail = error?.cause?.message || error?.message || String(error);
  const proxy = process.env.HTTPS_PROXY || process.env.https_proxy || process.env.HTTP_PROXY || process.env.http_proxy;
  const lines = [
    `Network request failed for ${url}.`,
    code ? `Network code: ${code}.` : '',
    detail ? `Details: ${detail}` : '',
    proxy ? `A proxy is configured (${proxy.replace(/:\/\/[^/@]+@/, '://***@')}). Ensure Node.js is allowed to use it.` : 'No HTTP(S) proxy environment variable was detected.',
    'Check DNS, firewall/TLS inspection, corporate proxy access, and connectivity to api.veracode.com:443.'
  ].filter(Boolean);
  return lines.join(' ');
}

export class VeracodeClient {
  constructor({ host, apiId, apiKey, retries = 3, timeoutMs = 300000 }) {
    this.host = host;
    this.apiId = apiId;
    this.apiKey = apiKey;
    this.retries = Math.max(0, Number(retries) || 0);
    this.timeoutMs = Math.max(1000, Number(timeoutMs) || 300000);
  }

  async request(method, urlPath, body, extraHeaders = {}, options = {}) {
    const url = `https://${this.host}${urlPath}`;
    const maxAttempts = options.noRetry ? 1 : this.retries + 1;

    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      const headers = {
        Authorization: authorizationHeader({ apiId: this.apiId, apiKeyHex: this.apiKey, host: this.host, urlPath, method }),
        Accept: 'application/json',
        'User-Agent': 'veracode-enterprise/7.8',
        ...extraHeaders
      };
      let payload;
      if (body !== undefined && body !== null) {
        payload = typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body);
        if (!headers['Content-Type']) headers['Content-Type'] = 'application/json';
      }

      try {
        const response = await fetch(url, { method, headers, body: payload, signal: AbortSignal.timeout(this.timeoutMs) });
        const text = await response.text();
        if (!response.ok) {
          let detail = text;
          try {
            const parsed = text ? JSON.parse(text) : {};
            detail = parsed.message || parsed.error || parsed.error_description || parsed.detail || text;
          } catch {}

          if (attempt < maxAttempts && RETRYABLE_STATUS.has(response.status)) {
            const delay = Math.min(1000 * (2 ** (attempt - 1)), 10000);
            console.warn(`Veracode API returned HTTP ${response.status}. Retrying in ${delay / 1000}s (${attempt}/${maxAttempts - 1})...`);
            await sleep(delay);
            continue;
          }
          if (response.status === 401) {
            throw new VeracodeApiError('Veracode authentication failed (HTTP 401). The HMAC API ID/Secret Key may be incorrect, expired, revoked, or mismatched.', { status: 401, url });
          }
          if (response.status === 403) {
            throw new VeracodeApiError(`Veracode authorization failed (HTTP 403). The credentials may not have the required Pipeline Scan role.${detail ? ` Details: ${detail}` : ''}`, { status: 403, url });
          }
          throw new VeracodeApiError(`Veracode API HTTP ${response.status}${detail ? `: ${detail}` : ''}`, { status: response.status, url });
        }
        if (!text.trim()) return {};
        try { return JSON.parse(text); } catch { return { text }; }
      } catch (error) {
        if (error instanceof VeracodeApiError) throw error;
        const code = causeCode(error);
        const retryable = RETRYABLE_CODES.has(code) || error?.name === 'TimeoutError' || error?.name === 'AbortError' || error?.message === 'fetch failed';
        if (attempt < maxAttempts && retryable) {
          const delay = Math.min(1000 * (2 ** (attempt - 1)), 10000);
          console.warn(`Network call failed${code ? ` (${code})` : ''}. Retrying in ${delay / 1000}s (${attempt}/${maxAttempts - 1})...`);
          await sleep(delay);
          continue;
        }
        throw new VeracodeApiError(networkMessage(error, url), { code, url, cause: error });
      }
    }
    throw new VeracodeApiError(`Request failed after ${maxAttempts} attempts: ${url}`, { url });
  }

  async validateCredentials() {
    // A deliberately non-existent scan ID provides a read-only signed request.
    // HTTP 400/404 confirms that the request passed HMAC authentication without creating a scan.
    const probeId = '00000000-0000-0000-0000-000000000000';
    try {
      await this.request('GET', `/pipeline_scan/v1/scans/${probeId}`, undefined, {}, { noRetry: true });
      return true;
    } catch (error) {
      if (error instanceof VeracodeApiError && [400, 404].includes(error.status)) return true;
      throw error;
    }
  }

  async uploadSegment(scanId, index, filePath) {
    const boundary = `----VeracodeNode${crypto.randomBytes(12).toString('hex')}`;
    const file = fs.readFileSync(filePath);
    const prefix = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="${path.basename(filePath)}"\r\nContent-Type: application/octet-stream\r\n\r\n`);
    const suffix = Buffer.from(`\r\n--${boundary}--\r\n`);
    return this.request('PUT', `/pipeline_scan/v1/scans/${scanId}/segments/${index}`, Buffer.concat([prefix, file, suffix]), { 'Content-Type': `multipart/form-data; boundary=${boundary}` });
  }
}

function splitFile(filePath, segments) {
  const data = fs.readFileSync(filePath); const files = []; const base = Math.floor(data.length / segments); let remainder = data.length % segments; let offset = 0;
  for (let i = 0; i < segments; i++) {
    const size = base + (remainder-- > 0 ? 1 : 0); const p = `${filePath}.segment-${String(i).padStart(4, '0')}`;
    fs.writeFileSync(p, data.subarray(offset, offset + size)); offset += size; files.push(p);
  }
  return files;
}

export async function validateVeracodeAccess(config, secrets) {
  const client = new VeracodeClient({
    host: config.api_host,
    apiId: secrets.api_id,
    apiKey: secrets.api_key,
    retries: config.network_retries,
    timeoutMs: Number(config.auth_timeout_seconds || 30) * 1000
  });
  await client.validateCredentials();
}

export async function runPipelineScan(config, secrets, artifact, projectName) {
  const stat = fs.statSync(artifact);
  const hash = crypto.createHash('sha256').update(fs.readFileSync(artifact)).digest('hex');
  const client = new VeracodeClient({ host: config.api_host, apiId: secrets.api_id, apiKey: secrets.api_key, retries: config.network_retries, timeoutMs: 300000 });
  const created = await client.request('POST', '/pipeline_scan/v1/scans', {
    binary_name: path.basename(artifact), binary_size: stat.size, binary_hash: hash,
    project_name: projectName, dev_stage: config.development_stage || 'DEVELOPMENT'
  });
  const scanId = String(created.scan_id || '');
  const segmentCount = Number(created.binary_segments_expected || 0);
  if (!scanId || segmentCount < 1) throw new Error('Invalid scan creation response');
  const segments = splitFile(artifact, segmentCount);
  try {
    for (let i = 0; i < segments.length; i++) {
      const percent = Math.round(((i + 1) / segments.length) * 100);
      console.log(`Uploading segment ${i + 1}/${segments.length} (${percent}%)`);
      await client.uploadSegment(scanId, i, segments[i]);
    }
    await client.request('PUT', `/pipeline_scan/v1/scans/${scanId}`, { scan_status: 'STARTED' });
    const deadline = Date.now() + Number(config.max_scan_minutes || 60) * 60000;
    let details = {};
    while (Date.now() < deadline) {
      await sleep(Number(config.poll_seconds || 20) * 1000);
      details = await client.request('GET', `/pipeline_scan/v1/scans/${scanId}`);
      const status = String(details.scan_status || '').toUpperCase(); console.log(`Scan status: ${status}`);
      if (status === 'SUCCESS') break;
      if (['ERROR', 'FAILED', 'CANCELLED'].includes(status)) throw new Error(`Scan ended with ${status}`);
    }
    if (String(details.scan_status || '').toUpperCase() !== 'SUCCESS') throw new Error('Scan timeout');
    console.log('Downloading findings (100%)');
    const results = await client.request('GET', `/pipeline_scan/v1/scans/${scanId}/findings`);
    return { results, metadata: { scan_id: scanId, binary_size: stat.size, binary_hash_sha256: hash, scan_status: 'SUCCESS', completed: new Date().toISOString() } };
  } finally { for (const p of segments) { try { fs.unlinkSync(p); } catch {} } }
}
