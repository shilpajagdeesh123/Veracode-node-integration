#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import { locatePaths } from './paths.js';
import { readJson, safeName, trimQuotes } from './utils.js';
import { loadOrPromptCredentials } from './credentials.js';
import { ask, choose } from './terminal.js';
import { discoverProjects } from './discovery.js';
import { packageTarget, stageExistingPackage } from './packager.js';
import { runPipelineScan, validateVeracodeAccess } from './api.js';
import { createOutputDir, normalizeResults, writeScanOutputs } from './results.js';

async function main() {
  const freshStart = process.argv.includes('--fresh-start');
  const runId = new Date().toISOString().replace(/[:.]/g, '-');
  const { home, repo } = locatePaths();
  console.log('==========================================================');
  console.log(' Veracode Enterprise Agent V7.7 (Node.js)');
  console.log(` New session: ${runId}`);
  console.log(freshStart ? ' Workflow reset: starting from step 1' : ' Workflow: starting from step 1');
  console.log('==========================================================');
  const config = { api_host: 'api.veracode.com', development_stage: 'DEVELOPMENT', poll_seconds: 20, max_scan_minutes: 60, network_retries: 3, auth_timeout_seconds: 30, blocking_severities: ['very high', 'high', '5', '4'], ...(readJson(path.join(home, 'config', 'scanner.json'), {}) || {}) };
  if (!config.api_host) config.api_host = 'api.veracode.com';
  console.log('Step 1/4: Checking local HMAC credential configuration...');
  const secrets = await loadOrPromptCredentials(home);
  config.api_host = secrets.api_host || config.api_host;
  console.log('Step 2/4: Credential file is ready.');
  console.log('Step 3/4: Validating network access and HMAC authentication...');
  await validateVeracodeAccess(config, secrets);
  console.log('Authentication validation successful.');
  console.log('Step 4/4: Starting a new scan selection workflow.');
  console.log('No previous project selection or scan session is resumed.');
  const mode = await choose('Select scan mode', ['PROJECT/MODULE - discover and scan repository application', 'EXISTING PACKAGE - submit ZIP/JAR/WAR/EAR unchanged']);
  let target, artifact, scope;
  if (mode === 1) {
    scope = 'EXISTING_PACKAGE';
    artifact = trimQuotes(await ask('Full package path'));
    if (!fs.existsSync(artifact) || !fs.statSync(artifact).isFile()) throw new Error(`Package not found: ${artifact}`);
    target = { path: path.dirname(artifact), kind: 'existing-package' };
  } else {
    scope = 'PROJECT';
    const targets = discoverProjects(repo);
    if (!targets.length) throw new Error('No Maven, Angular, Node, or mainframe project found');
    const selected = await choose('Select project/module', targets.map(t => `${path.relative(repo, t.path) || '.'} (${t.kind})`));
    target = targets[selected];
  }
  let name = safeName(path.basename(target.path));
  if (mode === 1) name = safeName(path.basename(artifact, path.extname(artifact)));
  const output = createOutputDir(repo, name, target.kind === 'mainframe');
  const packageDir = path.join(output, 'package'); fs.mkdirSync(packageDir, { recursive: true });
  artifact = mode === 0 ? packageTarget(target, packageDir, scope) : stageExistingPackage(artifact, packageDir);
  console.log(`Target : ${target.path}`); console.log(`Type   : ${target.kind}`); console.log(`Output : ${output}`); console.log(`Package: ${artifact}`);
  const { results, metadata } = await runPipelineScan(config, secrets, artifact, name);
  const normalized = normalizeResults(results, scope, name, config.blocking_severities);
  Object.assign(metadata, { scope, target: name, target_path: target.path, target_type: target.kind, artifact, api_host: config.api_host,
    source_output_layout: path.join('.github', 'Output', name, target.kind === 'mainframe' ? 'src' : '', '<date>').split(path.sep).join('/') });
  const status = { generated_at: new Date().toISOString(), target: name, pipeline_scan_status: 'SUCCESS', finding_count: normalized.finding_count,
    blocking_findings: normalized.blocking_finding_count, results_json: path.join(output, 'results.json') };
  writeScanOutputs({ output, raw: results, normalized, metadata, status });
  console.log('Scan completed successfully.');
  console.log(`Authoritative remediation input: ${path.join(output, 'results.json')}`);
  console.log(`Readable CSV: ${path.join(output, 'results.csv')}`);
}

main().catch(error => {
  console.error('==========================================================');
  console.error(`ERROR: ${error.message}`);
  if (error.code) console.error(`CODE : ${error.code}`);
  if (error.status) console.error(`HTTP : ${error.status}`);
  if (error.url) console.error(`URL  : ${error.url}`);
  if (process.env.VERACODE_DEBUG === '1' && error.stack) console.error(error.stack);
  console.error('Set VERACODE_DEBUG=1 to print the full stack trace.');
  console.error('==========================================================');
  process.exitCode = 1;
});
