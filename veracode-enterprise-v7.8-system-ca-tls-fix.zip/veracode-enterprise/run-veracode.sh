#!/usr/bin/env sh
set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 18 or later is required and was not found in PATH." >&2
  exit 1
fi

# Node.js 24+ can use HTTP_PROXY/HTTPS_PROXY through this setting.
export NODE_USE_ENV_PROXY=1

TLS_MODE="Node bundled CA store"
if node --help 2>/dev/null | grep -F -- "--use-system-ca" >/dev/null 2>&1; then
  case " ${NODE_OPTIONS-} " in
    *" --use-system-ca "*) ;;
    *) NODE_OPTIONS="${NODE_OPTIONS:+$NODE_OPTIONS }--use-system-ca"; export NODE_OPTIONS ;;
  esac
  TLS_MODE="operating-system trusted certificate store"
fi

CORPORATE_CA="$SCRIPT_DIR/certs/corporate-root-ca.pem"
if [ -f "$CORPORATE_CA" ]; then
  NODE_EXTRA_CA_CERTS="$CORPORATE_CA"
  export NODE_EXTRA_CA_CERTS
  TLS_MODE="$TLS_MODE plus certs/corporate-root-ca.pem"
fi

echo "=========================================================="
echo " Veracode Enterprise launcher V7.8"
echo "=========================================================="
echo "TLS trust: $TLS_MODE"
echo "Step 1: Checking config/veracode-secrets.json..."
node "$SCRIPT_DIR/src/ensure-credentials.js" || {
  echo "ERROR: Veracode credentials were not configured." >&2
  exit 1
}

echo "Step 2: Starting Veracode scan workflow..."
node "$SCRIPT_DIR/src/index.js" --fresh-start "$@"
EXIT_CODE=$?
if [ "$EXIT_CODE" -ne 0 ]; then
  echo "Veracode scan ended with exit code $EXIT_CODE." >&2
  echo "If the error contains UNABLE_TO_GET_ISSUER_CERT_LOCALLY, obtain your" >&2
  echo "corporate root/intermediate CA in PEM format and save it as:" >&2
  echo "  $CORPORATE_CA" >&2
fi
exit "$EXIT_CODE"
