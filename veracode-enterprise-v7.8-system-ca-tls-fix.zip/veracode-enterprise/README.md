# Veracode Enterprise Agent V7.4 — Node.js

Cross-platform Veracode API scan package using only built-in Node.js modules.

## Start without Copilot

Windows, from the repository root:

```text
veracode-enterprise\run-veracode.bat
```

macOS or Linux:

```text
./veracode-enterprise/run-veracode.sh
```

## Start with Copilot

Select `veracode-agent`, then enter:

```text
Start Veracode API scan.
```

Copilot runs a fresh process:

```text
node ./veracode-enterprise/src/index.js --fresh-start
```

Every execution starts again from credential validation, validates API connectivity/authentication, and then opens scan-mode selection. Existing credentials and results are preserved.

## Credentials

The scanner checks `config/veracode-secrets.json`. If the file exists, credential prompting is bypassed. Only when the file does not exist, the terminal asks for the HMAC API ID and hidden HMAC API key. The default host is `api.veracode.com`.

## Requirements

- Node.js 18 or later in PATH
- Valid Veracode HMAC API credentials
- Network access to `api.veracode.com`
- No administrator rights required
- No external npm dependencies

## Tests

```text
cd veracode-enterprise
npm test
```

## Network diagnostics

The client retries transient network failures and HTTP 408/429/5xx responses. It prints DNS, timeout, socket, HTTP status, request URL, and proxy diagnostics instead of only `fetch failed`. Set `VERACODE_DEBUG=1` for a full stack trace. Launchers set `NODE_USE_ENV_PROXY=1` so supported Node.js versions can use `HTTP_PROXY`, `HTTPS_PROXY`, and `NO_PROXY`.
