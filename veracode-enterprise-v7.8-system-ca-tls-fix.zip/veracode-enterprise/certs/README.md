# Corporate TLS certificate (optional fallback)

The launchers first try to use certificates already trusted by the operating system through Node.js `--use-system-ca`.

If your organization performs HTTPS/TLS inspection and Node.js still reports:

```text
UNABLE_TO_GET_ISSUER_CERT_LOCALLY
```

ask your IT/security team for the organization’s trusted **root or intermediate CA certificate** in Base-64 PEM format and save it as:

```text
veracode-enterprise/certs/corporate-root-ca.pem
```

The file must contain one or more blocks in this form:

```text
-----BEGIN CERTIFICATE-----
...
-----END CERTIFICATE-----
```

Do not place private keys in this folder. Do not set `NODE_TLS_REJECT_UNAUTHORIZED=0`; the package intentionally keeps TLS certificate verification enabled.
