import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { loadOrPromptCredentials } from '../src/credentials.js';

test('existing secrets file bypasses prompting based on file presence', async () => {
  const home = fs.mkdtempSync(path.join(os.tmpdir(), 'veracode-presence-'));
  const config = path.join(home, 'config');
  fs.mkdirSync(config, { recursive: true });
  fs.writeFileSync(path.join(config, 'veracode-secrets.json'), JSON.stringify({
    api_id: 'existing-id', api_key: 'existing-key', api_host: 'api.veracode.com'
  }));
  const result = await loadOrPromptCredentials(home);
  assert.equal(result.api_id, 'existing-id');
  assert.equal(result.api_key, 'existing-key');
});
