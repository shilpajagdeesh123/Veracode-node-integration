import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeSecrets, credentialsAreValid } from '../src/credentials.js';

test('normalizeSecrets safely handles null and non-object JSON values', () => {
  for (const value of [null, undefined, '', 'text', 123, true, []]) {
    assert.deepEqual(normalizeSecrets(value), {
      api_id: '',
      api_key: '',
      api_host: 'api.veracode.com'
    });
  }
});

test('normalizeSecrets removes invisible characters and whitespace', () => {
  assert.deepEqual(normalizeSecrets({
    api_id: '  id\u200B  ',
    api_key: '\uFEFFkey\u2060',
    api_host: ' api.veracode.com '
  }), {
    api_id: 'id',
    api_key: 'key',
    api_host: 'api.veracode.com'
  });
});

test('credentialsAreValid rejects missing and template credentials', () => {
  assert.equal(credentialsAreValid(null), false);
  assert.equal(credentialsAreValid({ api_id: 'id' }), false);
  assert.equal(credentialsAreValid({ api_id: 'REPLACE_WITH_HMAC_API_ID', api_key: 'key' }), false);
  assert.equal(credentialsAreValid({ api_id: 'id', api_key: 'REPLACE_WITH_HMAC_API_KEY' }), false);
  assert.equal(credentialsAreValid({ api_id: 'id', api_key: 'key' }), true);
});
