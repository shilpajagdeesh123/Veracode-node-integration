@echo off
setlocal EnableExtensions
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js 18 or later is required and was not found in PATH.
  echo Ask your organization to provide the approved Node.js runtime.
  exit /b 1
)

rem Node.js 24+ can use HTTP_PROXY/HTTPS_PROXY through this setting.
set "NODE_USE_ENV_PROXY=1"

rem Trust certificates installed in the Windows certificate store when supported.
set "TLS_MODE=Node bundled CA store"
node --help 2>nul | findstr /C:"--use-system-ca" >nul
if not errorlevel 1 (
  if defined NODE_OPTIONS (
    echo %NODE_OPTIONS% | findstr /C:"--use-system-ca" >nul
    if errorlevel 1 set "NODE_OPTIONS=%NODE_OPTIONS% --use-system-ca"
  ) else (
    set "NODE_OPTIONS=--use-system-ca"
  )
  set "TLS_MODE=Windows trusted certificate store"
)

rem Optional fallback for organizations that provide a PEM certificate file.
set "CORPORATE_CA=%~dp0certs\corporate-root-ca.pem"
if exist "%CORPORATE_CA%" (
  set "NODE_EXTRA_CA_CERTS=%CORPORATE_CA%"
  set "TLS_MODE=%TLS_MODE% plus certs\corporate-root-ca.pem"
)

echo ==========================================================
echo  Veracode Enterprise launcher V7.8
echo ==========================================================
echo TLS trust: %TLS_MODE%
echo Step 1: Checking config\veracode-secrets.json...
node "%~dp0src\ensure-credentials.js"
if errorlevel 1 (
  echo ERROR: Veracode credentials were not configured.
  exit /b 1
)

echo Step 2: Starting Veracode scan workflow...
node "%~dp0src\index.js" --fresh-start %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" (
  echo Veracode scan ended with exit code %EXIT_CODE%.
  if "%EXIT_CODE%"=="1" (
    echo If the error contains UNABLE_TO_GET_ISSUER_CERT_LOCALLY, obtain your
    echo corporate root/intermediate CA in PEM format and save it as:
    echo   %CORPORATE_CA%
  )
)
exit /b %EXIT_CODE%
