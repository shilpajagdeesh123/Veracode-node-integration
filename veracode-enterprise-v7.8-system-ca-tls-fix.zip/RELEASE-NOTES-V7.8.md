# Veracode Enterprise V7.8

## TLS and corporate-network improvements

- Windows, macOS, and Linux launchers detect whether Node.js supports `--use-system-ca`.
- When supported, all Node.js processes launched by the package use certificates trusted by the operating system.
- This allows Node.js to trust corporate TLS-inspection certificates already installed in the Windows certificate store, matching the behavior users often observed with the earlier Python implementation.
- An optional fallback certificate is supported at `veracode-enterprise/certs/corporate-root-ca.pem` through `NODE_EXTRA_CA_CERTS`.
- The system certificate store and optional PEM file can be used together.
- HTTPS certificate validation remains enabled. The package does not use `NODE_TLS_REJECT_UNAUTHORIZED=0`.
- Launchers print the active TLS trust mode before credential checks and scanning.
- Existing credential-file presence behavior is unchanged: if `config/veracode-secrets.json` exists, prompting is bypassed; if it does not exist, credentials are requested and saved.
