# Veracode Enterprise V7.6

## Credential bootstrap reliability fix

- Fixed the launcher crash when `config/veracode-secrets.json` contains `null`, is empty, is malformed, or contains a non-object JSON value.
- Both Windows and macOS/Linux launchers now treat missing, invalid, template, null, and incomplete credential files as unconfigured and prompt for HMAC API ID and hidden HMAC API key.
- Credentials continue to be saved to `veracode-enterprise/config/veracode-secrets.json` with the default host `api.veracode.com`.
- Added automated tests for null, malformed-shape, template, and normalized credentials.
