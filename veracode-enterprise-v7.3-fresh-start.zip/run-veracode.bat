@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js 18 or later is required and was not found in PATH.
  echo Ask your organization to provide the approved Node.js runtime.
  exit /b 1
)
node "%~dp0veracode-enterprise\src\index.js" --fresh-start
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" echo Veracode scan ended with exit code %EXIT_CODE%.
exit /b %EXIT_CODE%
