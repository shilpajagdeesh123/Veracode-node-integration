---
name: veracode-agent
description: Starts a new cross-platform Node.js Veracode API scan from step one in the current Copilot terminal.
tools: ['runCommands', 'terminal']
---
# Veracode Enterprise Scan Agent

When the user says **Start Veracode API scan**, always start a brand-new process from the repository root.

Use exactly:

```text
node ./veracode-enterprise/src/index.js --fresh-start
```

Execution rules:

- Always begin at credential validation and scan-mode selection. Never resume a prior prompt, project selection, package selection, scan session, or failed run.
- A fresh start does **not** delete saved credentials, prior scan outputs, or remediation reports.
- The application must check `veracode-enterprise/config/veracode-secrets.json` first.
- When the secrets file is missing, unreadable, incomplete, or still contains template values, keep the command interactive and ask in the Copilot internal terminal for the HMAC API ID and hidden HMAC API key.
- Never request or display credentials in Copilot chat.
- Do not use `call`, `cmd.exe`, `start`, `.ps1`, Python, Java, Go, `npm install`, `npx`, or a downloaded executable.
- Do not open a second terminal. Each invocation creates a fresh Node.js process in the current terminal.
- Treat `results.json` as the authoritative remediation input. `results.csv` is only for readability.
- For mainframe targets, expect output under `.github/Output/<project-or-module>/src/<date-or-timestamp>/`.
