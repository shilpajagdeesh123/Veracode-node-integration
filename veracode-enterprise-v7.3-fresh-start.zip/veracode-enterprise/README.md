# Veracode Enterprise Agent V7.3 — Node.js

Cross-platform Veracode API scan package using only built-in Node.js modules.

## Start without Copilot

Windows, from the repository root:

```text
run-veracode.bat
```

macOS or Linux:

```text
./run-veracode.sh
```

## Start with Copilot

Select `veracode-agent`, then enter:

```text
Start Veracode API scan.
```

Copilot runs a fresh process:

```text
node ./veracode-enterprise/src/index.js --fresh-start
```

Every execution starts again from credential validation and scan-mode selection. Existing credentials and results are preserved.

## Credentials

The scanner checks `config/veracode-secrets.json`. If it is missing or incomplete, the terminal asks for the HMAC API ID and hidden HMAC API key. The default host is `api.veracode.com`.

## Requirements

- Node.js 18 or later in PATH
- Valid Veracode HMAC API credentials
- Network access to `api.veracode.com`
- No administrator rights required
- No external npm dependencies

## Tests

```text
cd veracode-enterprise
npm test
```
