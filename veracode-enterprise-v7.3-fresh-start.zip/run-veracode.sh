#!/usr/bin/env sh
set -u
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 18 or later is required and was not found in PATH." >&2
  exit 1
fi
exec node "$SCRIPT_DIR/veracode-enterprise/src/index.js" --fresh-start
