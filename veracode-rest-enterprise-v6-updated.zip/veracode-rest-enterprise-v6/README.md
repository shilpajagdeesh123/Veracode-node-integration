# Veracode Enterprise V6

## Required repository layout

```text
repository-root/
├── .GitHub/
│   ├── agents/
│   │   └── veracode-remediation-agent.md
│   ├── skills/
│   │   └── veracode-remediation/
│   │       └── SKILL.md
│   └── output/                         # created when a scan runs
└── veracode-enterprise/
    ├── app/
    ├── config/
    ├── docs/
    ├── runtime/
    ├── create-secret-file.bat
    ├── run-Veracode.bat
    └── setup-runtime.bat
```

## Run

From a Windows terminal opened at the repository root:

```bat
veracode-enterprise\run-Veracode.bat
```

The launcher performs these steps automatically:

1. Checks for `veracode-enterprise\runtime\python\python.exe`.
2. Runs `setup-runtime.bat` when the bundled runtime is missing.
3. Checks `veracode-enterprise\config\veracode-secrets.json`.
4. When credentials are missing or incomplete, prompts for the HMAC API ID and a hidden HMAC API key.
5. Saves credentials locally with the default host `api.veracode.com`.
6. Continues to the Veracode scan workflow.

## Result paths

Mainframe projects/modules:

```text
.GitHub/output/<module-or-project>/src/<YYYY-MM-DD>/
```

Other applications:

```text
.GitHub/output/<module-or-project>/<YYYY-MM-DD>/
```

When a scan is repeated on the same date and the existing directory already contains `results.json`, a time subfolder is added to preserve the earlier result.

## Credential safety

`veracode-enterprise/config/veracode-secrets.json` is excluded by `.gitignore`. Do not commit or share this file.
