# Veracode Enterprise V7.5

## Launcher credential bootstrap

- `run-veracode.bat`, `run-veracode.cmd`, and `run-veracode.sh` now validate the local credential configuration before starting the scan workflow.
- The launchers invoke `src/ensure-credentials.js` immediately after checking Node.js.
- If `config/veracode-secrets.json` is missing, empty, incomplete, or still contains template values, the user is prompted for:
  - HMAC API ID
  - HMAC API key using hidden terminal input
- Credentials are saved locally to `veracode-enterprise/config/veracode-secrets.json`.
- The default API host remains `api.veracode.com`.
- The scan does not start when credential setup fails or is cancelled.
- Existing valid credentials are reused without prompting.
