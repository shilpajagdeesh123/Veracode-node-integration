# Veracode Enterprise Scan Skill

Run this skill when the user requests **Start Veracode API scan**.

From the repository root execute:

```text
node ./veracode-enterprise/src/index.js --fresh-start
```

Every invocation must be a new Node.js process and must restart the workflow from credential validation. Do not resume a previous interactive selection or scan state.

The application checks `veracode-enterprise/config/veracode-secrets.json`. If credentials are missing or invalid, allow it to prompt in the interactive terminal for the HMAC API ID and hidden API key. Never collect or echo credentials in chat.

Saved credentials and existing `.github/Output` files must not be deleted during a fresh start.
