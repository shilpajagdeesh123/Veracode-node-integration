import test from 'node:test';
import assert from 'node:assert/strict';
import { authorizationHeader } from '../src/hmac.js';

const base = {
  apiId: '0123456789abcdef0123456789abcdef',
  host: 'api.veracode.com',
  urlPath: '/healthcheck/status',
  method: 'GET',
  now: 1700000000000,
  nonce: Buffer.alloc(16, 1)
};

test('accepts copied secret containing spaces and invisible characters', () => {
  const raw = 'aa bb\ncc\u200Bdd-EE';
  const header = authorizationHeader({ ...base, apiKeyHex: raw });
  assert.match(header, /^VERACODE-HMAC-SHA-256 /);
});

test('reports normalized length only for genuinely incomplete secret', () => {
  assert.throws(
    () => authorizationHeader({ ...base, apiKeyHex: 'abc' }),
    /incomplete after normalization \(length 3\)/
  );
});
