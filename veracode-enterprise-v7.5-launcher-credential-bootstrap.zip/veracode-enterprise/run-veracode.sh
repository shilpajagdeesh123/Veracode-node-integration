#!/usr/bin/env sh
set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR" || exit 1

if ! command -v node >/dev/null 2>&1; then
  echo "ERROR: Node.js 18 or later is required and was not found in PATH." >&2
  exit 1
fi

# Node.js 24+ can use HTTP_PROXY/HTTPS_PROXY through this setting.
export NODE_USE_ENV_PROXY=1

echo "=========================================================="
echo " Veracode Enterprise launcher"
echo "=========================================================="
echo "Step 1: Checking config/veracode-secrets.json..."
node "$SCRIPT_DIR/src/ensure-credentials.js" || {
  echo "ERROR: Veracode credentials were not configured." >&2
  exit 1
}

echo "Step 2: Starting Veracode scan workflow..."
exec node "$SCRIPT_DIR/src/index.js" --fresh-start "$@"
