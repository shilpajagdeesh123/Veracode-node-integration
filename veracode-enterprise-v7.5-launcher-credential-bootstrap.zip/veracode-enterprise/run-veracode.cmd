@echo off
call "%~dp0run-veracode.bat" %*
exit /b %ERRORLEVEL%
