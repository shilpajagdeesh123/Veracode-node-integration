import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { createZip } from './zip.js';
import { isMainframeFile } from './discovery.js';
import { safeName } from './utils.js';

function copyFile(source, destination) { fs.mkdirSync(path.dirname(destination), { recursive: true }); fs.copyFileSync(source, destination); return destination; }
function executable(dir, name) { const p = path.join(dir, name); return fs.existsSync(p) ? p : null; }

export function packageTarget(target, packageDir, scope = 'PROJECT') {
  fs.mkdirSync(packageDir, { recursive: true });
  const name = safeName(path.basename(target.path));
  if (target.kind === 'mainframe') return createZip(target.path, path.join(packageDir, `${name}-${scope}-MAINFRAME.zip`), isMainframeFile);
  if (target.kind === 'angular' || target.kind === 'node') return createZip(target.path, path.join(packageDir, `${name}-${scope}.zip`));
  if (target.kind === 'maven') {
    const wrapper = process.platform === 'win32' ? executable(target.path, 'mvnw.cmd') : executable(target.path, 'mvnw');
    const command = wrapper || 'mvn';
    const result = spawnSync(command, ['clean', 'package', '-DskipTests'], { cwd: target.path, stdio: 'inherit', shell: process.platform === 'win32' });
    if (result.status !== 0) throw new Error(`Maven build failed with exit code ${result.status ?? 'unknown'}`);
    return createZip(target.path, path.join(packageDir, `${name}-PROJECT.zip`), p => {
      const ext = path.extname(p).toLowerCase();
      return p.split(path.sep).includes('target') && ['.jar', '.war', '.ear'].includes(ext);
    });
  }
  throw new Error(`Unsupported target type: ${target.kind}`);
}

export function stageExistingPackage(source, packageDir) { return copyFile(source, path.join(packageDir, path.basename(source))); }
