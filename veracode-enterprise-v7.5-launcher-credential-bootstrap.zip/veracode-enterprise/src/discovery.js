import fs from 'node:fs';
import path from 'node:path';

const ignored = new Set(['.git', '.github', '.idea', '.vscode', 'node_modules', 'target', 'dist', 'coverage', '.angular', '.cache', 'veracode-enterprise']);
const mainframeExt = new Set(['.cbl', '.cob', '.cobol', '.cpy', '.copy', '.pco', '.jcl', '.bms', '.pli', '.pl1', '.asm', '.s', '.mac']);

function mainframeRoot(fileDir) {
  const parts = path.resolve(fileDir).split(path.sep);
  const srcIndex = parts.map(x => x.toLowerCase()).lastIndexOf('src');
  return srcIndex > 0 ? parts.slice(0, srcIndex).join(path.sep) : fileDir;
}

export function discoverProjects(root) {
  const found = new Map();
  const walk = dir => {
    let entries;
    try { entries = fs.readdirSync(dir, { withFileTypes: true }); } catch { return; }
    for (const entry of entries) {
      const p = path.join(dir, entry.name);
      if (entry.isDirectory()) { if (!ignored.has(entry.name)) walk(p); continue; }
      const lower = entry.name.toLowerCase();
      if (lower === 'pom.xml') found.set(dir, 'maven');
      else if (lower === 'angular.json') found.set(dir, 'angular');
      else if (lower === 'package.json' && found.get(dir) !== 'angular') found.set(dir, 'node');
      if (mainframeExt.has(path.extname(lower))) {
        const candidate = mainframeRoot(dir);
        if (!found.has(candidate)) found.set(candidate, 'mainframe');
      }
    }
  };
  walk(root);
  return [...found.entries()].map(([projectPath, kind]) => ({ path: projectPath, kind })).sort((a, b) => a.path.localeCompare(b.path));
}

export function isMainframeFile(p) { return mainframeExt.has(path.extname(p).toLowerCase()); }
export function shouldIgnoreDir(name) { return ignored.has(name); }
