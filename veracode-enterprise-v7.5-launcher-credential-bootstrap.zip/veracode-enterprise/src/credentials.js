import fs from 'node:fs';
import path from 'node:path';
import { ask, readSecret } from './terminal.js';
import { readJson, writeJson } from './utils.js';

function cleanCredential(value) {
  return String(value ?? '')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .trim();
}

function normalizeSecrets(value = {}) {
  return {
    api_id: cleanCredential(value.api_id),
    api_key: cleanCredential(value.api_key),
    api_host: cleanCredential(value.api_host) || 'api.veracode.com'
  };
}

function valid(secrets) {
  return Boolean(
    secrets.api_id &&
    secrets.api_key &&
    !secrets.api_id.toUpperCase().startsWith('REPLACE_') &&
    !secrets.api_key.toUpperCase().startsWith('REPLACE_')
  );
}

export async function loadOrPromptCredentials(home) {
  const file = path.join(home, 'config', 'veracode-secrets.json');
  const existing = normalizeSecrets(readJson(file));

  if (valid(existing)) {
    return existing;
  }

  console.log('Veracode HMAC credentials are not configured.');
  const api_id = cleanCredential(await ask('HMAC API ID'));
  const api_key = cleanCredential(await readSecret('HMAC API key (hidden)'));
  const secrets = normalizeSecrets({ api_id, api_key, api_host: 'api.veracode.com' });

  if (!secrets.api_id) throw new Error('HMAC API ID is required.');
  if (!secrets.api_key) throw new Error('HMAC API key is required.');

  writeJson(file, secrets, 0o600);
  try { fs.chmodSync(file, 0o600); } catch {}
  console.log(`Credentials saved locally to ${file}`);
  return secrets;
}
