import fs from 'node:fs';
import path from 'node:path';

export function existsFile(p) { try { return fs.statSync(p).isFile(); } catch { return false; } }
export function existsDir(p) { try { return fs.statSync(p).isDirectory(); } catch { return false; } }
export function readJson(p, fallback = null) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch { return fallback; } }
export function writeJson(p, value, mode = 0o600) {
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(value, null, 2) + '\n', { mode });
  if (process.platform !== 'win32') fs.chmodSync(p, mode);
}
export function safeName(value) {
  const s = String(value || 'project').replace(/[^A-Za-z0-9._-]+/g, '-').replace(/^-+|-+$/g, '');
  return s || 'project';
}
export function trimQuotes(value) { return String(value || '').trim().replace(/^['"]|['"]$/g, ''); }
export function sleep(ms) { return new Promise(resolve => setTimeout(resolve, ms)); }
export function isoNow() { return new Date().toISOString(); }
export function dateStamp(d = new Date()) { return d.toISOString().slice(0, 10); }
export function timeStamp(d = new Date()) { return d.toTimeString().slice(0, 8).replaceAll(':', ''); }
export function toPosix(p) { return p.split(path.sep).join('/'); }
