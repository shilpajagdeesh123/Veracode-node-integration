import crypto from 'node:crypto';

function hm(key, data) {
  return crypto.createHmac('sha256', key).update(data).digest();
}

function normalizeHexSecret(value) {
  // Copying credentials from a browser or password manager can add spaces,
  // line breaks, zero-width marks, non-breaking spaces, or punctuation. Keep
  // only hexadecimal characters and let Veracode validate the resulting HMAC.
  return String(value ?? '').replace(/[^0-9a-f]/gi, '');
}

function decodeSecret(value) {
  const cleaned = normalizeHexSecret(value);
  if (!cleaned) throw new Error('HMAC API key is required.');

  // A hexadecimal byte string must contain pairs of characters. Do not reveal
  // the secret; report only its normalized length for troubleshooting.
  if (cleaned.length % 2 !== 0) {
    throw new Error(`HMAC API key is incomplete after normalization (length ${cleaned.length}). Re-copy the complete Veracode Secret Key.`);
  }
  return Buffer.from(cleaned, 'hex');
}

export function authorizationHeader({ apiId, apiKeyHex, host, urlPath, method, now = Date.now(), nonce = crypto.randomBytes(16) }) {
  const normalizedApiId = String(apiId ?? '')
    .replace(/[\u200B-\u200D\u2060\uFEFF]/g, '')
    .trim();
  if (!normalizedApiId) throw new Error('HMAC API ID is required.');

  const key = decodeSecret(apiKeyHex);
  const timestamp = String(now);
  const k1 = hm(key, nonce);
  const k2 = hm(k1, Buffer.from(timestamp));
  const k3 = hm(k2, Buffer.from('vcode_request_version_1'));
  const canonical = `id=${normalizedApiId}&host=${host}&url=${urlPath}&method=${String(method).toUpperCase()}`;
  const sig = hm(k3, Buffer.from(canonical)).toString('hex');
  return `VERACODE-HMAC-SHA-256 id=${normalizedApiId},ts=${timestamp},nonce=${nonce.toString('hex')},sig=${sig}`;
}
