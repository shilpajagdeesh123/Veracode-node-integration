#!/usr/bin/env node
import { locatePaths } from './paths.js';
import { loadOrPromptCredentials } from './credentials.js';

async function main() {
  const { home } = locatePaths();
  console.log('Checking Veracode credential file...');
  await loadOrPromptCredentials(home);
  console.log('Veracode credential configuration is ready.');
}

main().catch(error => {
  console.error(`ERROR: ${error.message}`);
  if (process.env.VERACODE_DEBUG === '1' && error.stack) {
    console.error(error.stack);
  }
  process.exitCode = 1;
});
