@echo off
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js 18 or later is required and was not found in PATH.
  echo Ask your organization to provide the approved Node.js runtime.
  exit /b 1
)

rem Node.js 24+ can use HTTP_PROXY/HTTPS_PROXY through this setting.
set "NODE_USE_ENV_PROXY=1"

echo ==========================================================
echo  Veracode Enterprise launcher
echo ==========================================================
echo Step 1: Checking config\veracode-secrets.json...
node "%~dp0src\ensure-credentials.js"
if errorlevel 1 (
  echo ERROR: Veracode credentials were not configured.
  exit /b 1
)

echo Step 2: Starting Veracode scan workflow...
node "%~dp0src\index.js" --fresh-start %*
set "EXIT_CODE=%ERRORLEVEL%"
if not "%EXIT_CODE%"=="0" echo Veracode scan ended with exit code %EXIT_CODE%.
exit /b %EXIT_CODE%
