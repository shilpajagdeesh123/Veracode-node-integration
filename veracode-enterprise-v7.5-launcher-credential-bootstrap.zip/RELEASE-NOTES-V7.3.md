# Veracode Enterprise Agent V7.3

- Renamed the runtime folder from `veracode-enterprise-node` to `veracode-enterprise`.
- Copilot execution now explicitly starts a new process from step 1 with `--fresh-start`.
- Credential validation runs before scan selection; missing credentials are requested in the interactive terminal with hidden API-key input.
- Added root-level `run-veracode.bat`, `run-veracode.cmd`, and `run-veracode.sh` launchers for execution without the Copilot agent.
- Fresh start does not delete valid credentials, prior results, or remediation evidence.
