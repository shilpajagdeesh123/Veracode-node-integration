# Veracode Enterprise Agent V7.4

- Added a read-only HMAC authentication and connectivity check before project selection and packaging.
- Replaced the generic `fetch failed` output with HTTP status, network error code, URL, underlying cause, proxy detection, and optional stack trace.
- Added retries with exponential backoff for transient socket failures and HTTP 408, 429, and 5xx responses.
- Added upload percentage and explicit findings-download progress.
- Added `network_retries` and `auth_timeout_seconds` settings in `config/scanner.json`.
- Enabled environment-proxy support for Node.js versions that support `NODE_USE_ENV_PROXY`.
- Moved all `.bat`, `.cmd`, and `.sh` launchers under the `veracode-enterprise` folder.
- Updated Copilot and standalone execution documentation for the new launcher paths.
