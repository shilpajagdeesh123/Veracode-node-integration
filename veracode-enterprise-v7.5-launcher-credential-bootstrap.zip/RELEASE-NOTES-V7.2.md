# Veracode Enterprise Node Agent V7.2

- Fixes HMAC keys copied with spaces, line breaks, zero-width marks, non-breaking spaces, or punctuation.
- Normalizes the saved Secret Key by retaining hexadecimal characters only.
- Removes the previous generic invalid-character error.
- Reports only normalized key length when the key is genuinely incomplete; the key itself is never logged.
- Veracode remains the authority for authentication through the actual signed API request.

Security: rotate any credential that has been displayed in screenshots or chat.
